package tier2.view;

public interface Tier2MovieManagerView {
	void show(String text);
}
