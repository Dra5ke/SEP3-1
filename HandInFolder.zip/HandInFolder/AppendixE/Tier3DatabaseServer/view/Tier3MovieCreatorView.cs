using System;

namespace Tier3ServerDatabase.view{
    public interface Tier3MovieCreatorView{
        void Show(String text);
    }
}