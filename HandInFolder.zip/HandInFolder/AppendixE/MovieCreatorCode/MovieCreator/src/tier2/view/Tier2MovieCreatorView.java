package tier2.view;

public interface Tier2MovieCreatorView {
	void show(String text);
}
